import React from 'react'

export const About = () => {
    return (
        <div>
             this is an about
             <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ut, placeat? Praesentium ad nihil ex aut ea ullam aliquam esse, saepe maxime sed omnis debitis quas, itaque soluta! Dignissimos, amet nostrum!</p>
        </div>
    )
}
